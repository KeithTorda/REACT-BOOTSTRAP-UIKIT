# admin-ui-kit

A reusable **React + Bootstrap 5** admin UI component library — installable as a package, themeable at
runtime, dark-mode ready, and shipping **26 complete page templates**.

Borrows the visual language of the
[School-Admin-Template-Bootstrap](https://github.com/StarCodeKh/School-Admin-Template-Bootstrap)
reference (floating rounded panels, thin borders, soft shadows, gradient accents) and contains **none**
of its content — no student, teacher, attendance, exam or fee logic. Build Inventory, HR, Accounting,
COMELEC, POS, CRM, DMS, Asset or Government systems on top of it.

No Tailwind. No backend. No database. No jQuery.

---

## Install it into a project

The kit ships a ready-made tarball — `admin-ui-kit-2.0.0.tgz` — in this folder.

```bash
# in your new project
npm install react react-dom react-router-dom
npm install "C:/Users/.../react-bootstrap-admin-ui-kit/admin-ui-kit-2.0.0.tgz"
```

```jsx
// main.jsx — ONE stylesheet, Bootstrap and Bootstrap Icons included
import 'admin-ui-kit/styles.css';
```

Make sure your `index.html` has `<meta charset="utf-8" />` (Vite's template already does) so the icon
glyphs decode correctly.

> **Rebuilding the tarball** after you change the kit: `npm run build:lib && npm pack`.
>
> **Installing the folder instead of the tarball** (`npm i ../react-bootstrap-admin-ui-kit`) creates a
> symlink, which makes your app load two copies of React. If you do it that way, add this to your
> project's `vite.config.js`:
> ```js
> resolve: { dedupe: ['react', 'react-dom', 'react-router-dom'] }
> ```
> The tarball route needs no such workaround — prefer it.

```jsx
// App.jsx
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ThemeProvider, AdminLayout, DataTable, StatsCard, Button } from 'admin-ui-kit';

const nav = [
  { section: 'Main', items: [
    { label: 'Dashboard', icon: 'speedometer2', path: '/' },
    { label: 'Records',   icon: 'table',        path: '/records' },
  ]},
];

export default function App() {
  return (
    <ThemeProvider defaultSettings={{ color: 'blue', mode: 'system' }}>
      <BrowserRouter>
        <Routes>
          <Route element={<AdminLayout navigation={nav} brand="My System" user={{ name: 'John Doe' }} />}>
            <Route index element={<Dashboard />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  );
}
```

That's the whole setup — sidebar, navbar, dark mode, theme switcher and responsive behaviour included.

## Run the showcase

```bash
npm install
npm run dev        # the full component + template browser
npm run build      # builds the showcase into build/
npm run build:lib  # rebuilds the installable package into dist/
```

> The showcase uses `BrowserRouter`, so a static host needs an SPA fallback (rewrite every path to
> `index.html`). Netlify: `/* /index.html 200`. Vercel: a catch-all rewrite.

---

## What's inside

**~100 components · ~230 variants · 26 page templates · 8 colour themes · light + dark**

| Category | Components |
|---|---|
| Theme | `ThemeProvider` `useTheme` `ThemeCustomizer` `ThemeToggle` |
| Layout | `AdminLayout` `AuthLayout` `BlankLayout` `Sidebar` `Navbar` `Header` `Footer` `PageHeader` `Breadcrumb` `ContentWrapper` |
| Cards | `Card` `StatsCard` `InfoCard` `ProfileCard` `ChartCard` `ActionCard` |
| Tables | `DataTable` `TableToolbar` `TableSearch` `TableFilter` `TablePagination` `TableActions` `downloadCsv` |
| Forms | `TextInput` `TextArea` `RichTextArea` `SelectInput` `MultiSelect` `Autocomplete` `TagsInput` `PasswordInput` `OTPInput` `NumberStepper` `MaskedInput` `RangeSlider` `Rating` `ColorPicker` `DateInput` `DateRangePicker` `FileUpload` `SearchInput` `Checkbox` `RadioGroup` `Switch` `RepeaterField` `FormGroup` `FormCard` `FormWizard` |
| Buttons | `Button` `IconButton` `ActionButton` `ButtonGroup` `SplitButton` `Fab` `ToggleGroup` `CopyButton` `SocialButton` |
| Feedback | `Alert` `Badge` `StatusDot` `Toast` `Spinner` `Skeleton` `SkeletonPreset` `Progress` `CircularProgress` `EmptyState` `ErrorState` |
| Overlays | `Modal` `ConfirmModal` `Drawer` `Dropdown` `Tooltip` `Popover` `ContextMenu` `CommandPalette` `Lightbox` |
| Navigation | `Tabs` `Accordion` `Pagination` `Stepper` `NavMenu` |
| Charts | `LineChart` `BarChart` `PieChart` `DoughnutChart` `RadarChart` `PolarChart` `ScatterChart` `Sparkline` |
| Data display | `Avatar` `AvatarGroup` `DetailList` `ListGroup` `Timeline` `ActivityFeed` `MessageList` `NotificationDropdown` `CalendarWidget` `InvoiceLayout` `KanbanBoard` `FileManager` `ChatPanel` `CommentThread` `PricingCard` `Gallery` |
| Auth | `AuthCard` `LoginCard` `RegisterCard` `ForgotPasswordCard` `ResetPasswordCard` `OTPVerifyCard` `LockScreenCard` |
| Hooks | `useToggle` `useToasts` `useMediaQuery` `useClickOutside` `useTableData` |

Open **Cheatsheet** in the running app for a searchable, copy-paste list of every one of these.

## Page templates (`src/templates/`)

| Group | Templates |
|---|---|
| Dashboards | Analytics · Sales/POS · Project · Minimal · Monitoring |
| CRUD | List · Create/Edit form · Detail · Wizard |
| Records | Profile · Settings (tabbed) · Audit log |
| Work | Kanban board · Calendar · Inbox/chat · File manager |
| Documents | Invoice list · Invoice view · Report · Pricing |
| Auth & errors | Sign in · Sign up · 404 · 403 · 500 · Maintenance |

Copy the file, rename it, swap the data source. That's how you start a new system in a day.

## Theming

Everything is CSS custom properties, so one switch re-skins the entire kit.

```jsx
const { settings, set, isDark, toggleMode } = useTheme();

set({ mode: 'dark' });               // light · dark · system
set({ color: 'violet' });            // green blue violet indigo orange rose teal slate
set({ layout: 'horizontal' });       // sidebar horizontal boxed rail stacked
set({ sidebarStyle: 'gradient' });   // light dark floating gradient transparent
set({ navbarStyle: 'dark' });        // light dark transparent
set({ density: 'compact' });         // comfortable · compact
set({ radius: 'rounded' });          // sharp · default · rounded
set({ rtl: true });                  // right-to-left
```

Users can change all of this themselves from the settings drawer (the slider button on the right edge),
and the choice is remembered in `localStorage`. Charts read the same tokens, so they re-colour too.

Override the palette wholesale by redefining tokens in your own CSS:

```css
:root { --primary: #0d6efd; --border-radius: 6px; --sidebar-width: 240px; }
```

## Core patterns

**Config-driven sidebar** — edit the array, never the JSX:

```js
const nav = [
  { label: 'Dashboard', icon: 'speedometer2', path: '/' },
  { label: 'Records', icon: 'table', children: [
      { label: 'All', path: '/records' },
      { label: 'Archived', path: '/records/archived' },
  ]},
];
```

**One DataTable for every list screen:**

```jsx
<DataTable
  columns={[
    { key: 'name',   label: 'Name' },
    { key: 'amount', label: 'Amount', align: 'right', total: 'sum' },
    { key: 'status', label: 'Status', render: v => <Badge variant="success">{v}</Badge> },
  ]}
  data={rows}
  searchable pagination selectable expandable
  stickyHeader columnToggle exportable showTotals editable
  filters={[{ key: 'status', label: 'Status', options: ['Active', 'Pending'] }]}
  actions={[{ icon: 'pencil', label: 'Edit', onClick: edit }]}
/>
```

Server-side paging is one prop away:

```jsx
<DataTable serverSide data={rows} total={count} pagination searchable
  onQueryChange={({ page, pageSize, query, sort, filters }) => fetchPage(...)} />
```

**Consistent form API** — every control takes `label`, `value`, `onChange`, `required`, `disabled`,
`error`, `helperText`, `size`, and supports `horizontal` / `floating` / `inline` layouts.

## Responsive behaviour

| Breakpoint | Sidebar |
|---|---|
| ≥ 1200px | fixed 270px |
| 992–1199px | 76px icon rail |
| < 992px | off-canvas drawer with backdrop |

## Notes

* Bootstrap's **CSS** only — modals, dropdowns, tabs, accordions, toasts, drawers, the command palette,
  the calendar and the off-canvas sidebar are all React state (`useState` / `useEffect` / `useRef`).
* Sample data in `src/data/` is generic placeholder data (John Doe, Jane Smith, Alex Morgan).
* `src/index.js` re-exports the whole library; templates live in `src/templates/`.

See `PLAN.md` (v1 extraction notes) and `PLAN-V2-VARIATIONS.md` (the variant/theming/template plan).
